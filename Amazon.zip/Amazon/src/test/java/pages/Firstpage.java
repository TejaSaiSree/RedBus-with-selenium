package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilies.ExplicitCode;

public class Firstpage {
	WebDriver dr;
	ExplicitCode e;
public Firstpage(WebDriver dr) {
	this.dr=dr;
	e= new ExplicitCode();
	
}
By choose=By.xpath("//input[@type='email']");
public void Chooseaccount(String s) {
	dr.findElement(choose).sendKeys(s);
	dr.findElement(By.xpath("//input[@type='submit']")).click();
	e.Screenshot();
}

}
