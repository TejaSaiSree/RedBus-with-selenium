package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilies.ExplicitCode;

public class SecondPage {
	WebDriver dr;
	ExplicitCode e;
	public SecondPage(WebDriver dr) {
		this.dr=dr;
		e= new ExplicitCode();
	}
	By Id=By.xpath("//input[@name='UserName']");
	By pass=By.xpath("//input[@name='Password']");
	By btn= By.xpath("//input[@id='Log_On1']");
	By Btn1=By.xpath("//input[@id='idBtn_Back']");
	By name=By.xpath("//div[@class='media']//div[2]//p");
	By train=By.xpath("//div[@class='media']//span[@class='job-title']");
	public void ChooseId(String s) {
		WebElement d=e.waitElement(Id, 50);
		dr.findElement(Id).sendKeys(s);
	}
	public void ChoosePass(String s) {
		dr.findElement(pass).sendKeys(s);
	}
	public void Clickbtn() {
		dr.findElement(btn).click();
	}
	public void Clickbtn1() {
		WebElement d=e.waitElement(Btn1, 50);
		dr.findElement(Btn1).click();
	}
	public String Name() {
		String s=dr.findElement(name).getText();
		return s;
	}
	public String Name1() {
		String s=dr.findElement(train).getText();
		return s;
	}
	public void login(String s,String p,String r) {
		this.ChooseId(s);
		this.ChoosePass(p);
		this.Clickbtn();
		try {
			Thread.sleep(40000);
		} catch (InterruptedException e1) {
			
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		e.Screenshot();
		this.Clickbtn1();
	}
}
