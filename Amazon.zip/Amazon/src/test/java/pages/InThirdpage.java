package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilies.ExplicitCode;

public class InThirdpage {

	WebDriver dr;
	ExplicitCode e;
public InThirdpage(WebDriver dr) {
	this.dr=dr;
	e= new ExplicitCode();
}
By fir=By.xpath("//ul[@class='tag-list']/li[1]");
By Sec=By.xpath("//ul[@class='tag-list']/li[2]");
By thr=By.xpath("//ul[@class='tag-list']/li[3]");
public void acq() {
	dr.findElement(fir).click();
}
public String Digi() {
	String s= dr.findElement(Sec).getText();
	return s;
}
public String outreach() {
	String s= dr.findElement(thr).getText();
	return s;
}
public void add1() {
	this.acq();
	this.Digi();
	this.outreach();
	e.Screenshot();
}
}
