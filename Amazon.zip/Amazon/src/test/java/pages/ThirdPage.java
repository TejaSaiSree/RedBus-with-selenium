package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilies.ExplicitCode;

public class ThirdPage {
	WebDriver dr;
	ExplicitCode e;
public ThirdPage(WebDriver dr) {
	this.dr=dr;
	e= new ExplicitCode();
}
By personal=By.xpath("//ul[@class='nav nav-pills pull-right']//li[2]");
By add=By.xpath("/html/body/appearance-refresher[1]/header/div[1]/div[2]/div/div/div[2]/div/div/div/div/div/div/div[2]/ul/li/button");
By Ac= By.xpath("//span[@id='316743-label']");
By Di=By.xpath("//span[@id='317709-label']");
By Or=By.xpath("//span[@id='316861-label']");
By finish=By.xpath("/html/body/div/div/div[3]/div/span/button");
public void Chooseper() {
	WebElement r=e.clickElement(personal, 30);
	dr.findElement(personal).click();
}
public void Chooseadd() {
	WebElement r=e.clickElement(add, 30);
	dr.findElement(add).click();
}
public void Chooseadd1() {
	WebElement r=e.clickElement(Ac, 30);
	dr.findElement(Ac).click();
}
public void Chooseadd2() {
	WebElement r=e.clickElement(Di, 40);
	dr.findElement(Di).click();
}
public void Chooseadd3() {
	WebElement r=e.clickElement(Or, 50);
	dr.findElement(Or).click();
}
public void Chooseadd4() {
	WebElement r=e.clickElement(finish, 30);
	dr.findElement(finish).click();
}
public void personalize() {
	this.Chooseper();
	this.Chooseadd();
	this.Chooseadd1();
	this.Chooseadd2();
	this.Chooseadd3();
	this.Chooseadd4();
	e.Screenshot();
	
}
}
