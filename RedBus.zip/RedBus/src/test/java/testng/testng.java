package testng;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import Utilities.ExplixitCode;
import login.Login;
import login.aftersearch;

public class testng extends ExplixitCode{
	Login l;
	aftersearch a;
	@BeforeMethod
	public void launchbrowser() {
		launchbrowser("chrome");
	}
	@BeforeClass
	public void excel() {
		getExcel("Sheet1");
	}
	 @Test(priority=0,dataProvider="register")
	  public void f(String s,String p1) {
		  l=new Login(dr);
		  a= new aftersearch(dr);
		 l. busses(s,p1);
		 a.forwardate();
		 String s1=a.second();
		 Assert.assertTrue(s1.contains("Volvo"));
		 String s2=a.Price1();
		 Assert.assertTrue(s2.contains("1150"));
		
	  }
	 @DataProvider(name="register")
	  public String[][] register(){
		   return testdata;
	  }

}
