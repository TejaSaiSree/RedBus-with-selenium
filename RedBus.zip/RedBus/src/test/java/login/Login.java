package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplixitCode;
import datepicker.dateobj;

public class Login {
	WebDriver dr;
	ExplixitCode  e;
	dateobj o;
	public Login(WebDriver dr) {
		this.dr=dr;
		e=new ExplixitCode ();
		o= new dateobj(dr);
	}
 By from=By.xpath("//input[@id='src']");
 By to=By.xpath("//input[@id='dest']");
 By search=By.xpath("//*[@class='fl button']");
 public void forwardate(String q) {
	 WebElement a=e.waitelement(from, 20);
	 a.sendKeys(q);
	 dr.findElement(By.xpath("//ul[@class='autoFill']//li")).click();
 }
 public void towardsdate(String q) {
	 WebElement a=e.waitelement(to, 20);
	 a.sendKeys(q);
	 dr.findElement(By.xpath("//ul[@class='autoFill']//li")).click();
 }
 public void clicksearch() {
	 WebElement a=e.waitelement(search, 20);
	 a.click();
 }
 public void busses(String u,String p) {
	 this.forwardate(u);
	 this.towardsdate(p);
	 o.datepicker();
	 e.Screenshot();
	 this.clicksearch();
 }
}
