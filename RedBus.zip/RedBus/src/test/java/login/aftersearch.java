package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplixitCode;

public class aftersearch {
WebDriver dr;
ExplixitCode  e;
public aftersearch(WebDriver dr) {
	this.dr=dr;
	e= new ExplixitCode();
}
By ac=By.xpath("/html/body/section/div[2]/div[1]/div/div[2]/div[1]/div/div[2]/ul[3]/li[3]/label[2]");
By secondbus=By.xpath("//ul[@class='bus-items']//li//div[2]");
By price=By.xpath("/html/body/section/div[2]/div[1]/div/div[2]/div[2]/div[3]/ul/div[1]/li/div/div[1]/div[1]/div[6]/div/div/span");
public void forwardate() {
//	 WebElement a=e.clickable(ac, 20);
//	 a.click();
	dr.findElement(ac).click();
}
public String  second() {
//	 WebElement a=e.waitelement(secondbus, 20);
//	return  a.getText();
	String a=dr.findElement(secondbus).getText();
	return a;
}
public String  Price1() {
//	 WebElement a=e.waitelement(price, 20);
//	return  a.getText();
	String a=dr.findElement(price).getText();
	e.Screenshot();
	return a;
}

}
