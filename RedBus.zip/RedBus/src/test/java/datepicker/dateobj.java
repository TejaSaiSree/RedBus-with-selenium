package datepicker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Utilities.ExplixitCode;



public class dateobj {
	WebDriver dr;
	ExplixitCode  e;	
	public  dateobj(WebDriver dr) {
		this.dr=dr;
		e=new ExplixitCode ();
	}
	String s="Apr 2020";
	By click1=
			By.xpath("//*[@class='fl icon-calendar_icon-new icon-onward-calendar icon']");
	By month=By.xpath("//*[@id='rb-calendar_onward_cal']//following::td[1]");
	By forward=By.xpath("//*[@id='rb-calendar_onward_cal']//following::td[2]");
	By date=By.xpath("//*[@class='rb-monthTable first last']//following::td");
	public void clicking() {
		WebElement a=e.clickable(click1, 100);
		a.click();
	}
	public void datepicker() {
	dr.findElement(click1).click();
	 String s1=dr.findElement(month).getText();
	 if(!s.equals(s1)) {
		 dr.findElement(forward).click();
		 s1=dr.findElement(month).getText();
		 List<WebElement> all=dr.findElements(date);
			for(WebElement f:all){
				String date=f.getText();
				if(date.equalsIgnoreCase("12")) {
					f.click();
					break;
				}
			}
	 }
	}
}
